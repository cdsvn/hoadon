<tr>
    <td colspan="11">
        <div style='padding: 5px;'><?= $description; ?>.</div>
    </td>
</tr>